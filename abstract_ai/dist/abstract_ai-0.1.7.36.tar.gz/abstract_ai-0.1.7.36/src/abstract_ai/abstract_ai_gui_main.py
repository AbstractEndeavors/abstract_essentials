from abstract_gui import AbstractBrowser
from .abstract_ai_gui_backend import GptManager
gpt_mgr = GptManager()
gpt_mgr.while_window()
